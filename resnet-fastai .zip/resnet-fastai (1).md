#  ModelArts平台上安装fastai对XAIIC数据集分类的笔记(一）

数据集的说明：对西安的热门景点、美食、特产、民俗、工艺品等图片进行分类，即首先识别出图片中物品的类别（比如大雁塔、肉夹馍等），然后根据图片分类的规则，输出该图片中物品属于景点、美食、特产、民俗和工艺品中的哪一种。

平台上有pytorch1.0.0只需执行pip install fastai用以集成fastai,之前用conda的安装模式导致安装失败，这可能是因为默认安装最新版本不兼容一些库的原因，也尝试了其它方式但没有gpu加速，总结：最省心省力的方式，直接!pip install fastai


```python
!pip install fastai
```

按fastai的推荐是要首先要执行下面3个代码，在modelarts上会出错，一些包不兼容，注释掉前两个就好了


```python
# %reload_ext autoreload
# %autoreload 2
%matplotlib inline
```


```python
from fastai.vision import *
from fastai.metrics import accuracy
```

本来batch_size设置128的，用densenet169模型会oom,之前的resnet50不会，我用的v100显卡有32G,也会oom!!!


```python
bs = 64
```


```python
PATH="./"
```

用from_csv直接读取csv格式的数据生成databunch很方便


```python
data = ImageDataBunch.from_csv(PATH, folder='train_data',csv_labels='train.csv',valid_pct=0.2,ds_tfms=get_transforms(),size=299,bs=64)
```


```python
data.show_batch(rows=3, figsize=(7,6))
```


![png](output_12_0.png)



```python
print(data.classes)
len(data.classes),data.c
```

    ['class_00', 'class_01', 'class_02', 'class_03', 'class_04', 'class_05', 'class_06', 'class_07', 'class_08', 'class_09', 'class_10', 'class_11', 'class_12', 'class_13', 'class_14', 'class_15', 'class_16', 'class_17', 'class_18', 'class_19', 'class_20', 'class_21', 'class_22', 'class_23', 'class_24', 'class_25', 'class_26', 'class_27', 'class_28', 'class_29', 'class_30', 'class_31', 'class_32', 'class_33', 'class_34', 'class_35', 'class_36', 'class_37', 'class_38', 'class_39', 'class_40', 'class_41', 'class_42', 'class_43', 'class_44', 'class_45', 'class_46', 'class_47', 'class_48', 'class_49', 'class_50', 'class_51', 'class_52', 'class_53']
    




    (54, 54)




```python
learn = cnn_learner(data, models.densenet169, metrics=error_rate)
```

    /home/ma-user/anaconda3/envs/Pytorch-1.0.0/lib/python3.6/site-packages/torchvision/models/densenet.py:212: UserWarning: nn.init.kaiming_normal is now deprecated in favor of nn.init.kaiming_normal_.
      nn.init.kaiming_normal(m.weight.data)
    


```python
learn.model
```




    Sequential(
      (0): Sequential(
        (0): Sequential(
          (conv0): Conv2d(3, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)
          (norm0): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          (relu0): ReLU(inplace)
          (pool0): MaxPool2d(kernel_size=3, stride=2, padding=1, dilation=1, ceil_mode=False)
          (denseblock1): _DenseBlock(
            (denselayer1): _DenseLayer(
              (norm1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(64, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer2): _DenseLayer(
              (norm1): BatchNorm2d(96, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(96, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer3): _DenseLayer(
              (norm1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(128, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer4): _DenseLayer(
              (norm1): BatchNorm2d(160, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(160, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer5): _DenseLayer(
              (norm1): BatchNorm2d(192, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(192, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer6): _DenseLayer(
              (norm1): BatchNorm2d(224, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(224, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
          )
          (transition1): _Transition(
            (norm): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (relu): ReLU(inplace)
            (conv): Conv2d(256, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (pool): AvgPool2d(kernel_size=2, stride=2, padding=0)
          )
          (denseblock2): _DenseBlock(
            (denselayer1): _DenseLayer(
              (norm1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(128, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer2): _DenseLayer(
              (norm1): BatchNorm2d(160, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(160, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer3): _DenseLayer(
              (norm1): BatchNorm2d(192, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(192, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer4): _DenseLayer(
              (norm1): BatchNorm2d(224, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(224, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer5): _DenseLayer(
              (norm1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(256, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer6): _DenseLayer(
              (norm1): BatchNorm2d(288, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(288, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer7): _DenseLayer(
              (norm1): BatchNorm2d(320, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(320, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer8): _DenseLayer(
              (norm1): BatchNorm2d(352, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(352, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer9): _DenseLayer(
              (norm1): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(384, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer10): _DenseLayer(
              (norm1): BatchNorm2d(416, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(416, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer11): _DenseLayer(
              (norm1): BatchNorm2d(448, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(448, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer12): _DenseLayer(
              (norm1): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(480, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
          )
          (transition2): _Transition(
            (norm): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (relu): ReLU(inplace)
            (conv): Conv2d(512, 256, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (pool): AvgPool2d(kernel_size=2, stride=2, padding=0)
          )
          (denseblock3): _DenseBlock(
            (denselayer1): _DenseLayer(
              (norm1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(256, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer2): _DenseLayer(
              (norm1): BatchNorm2d(288, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(288, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer3): _DenseLayer(
              (norm1): BatchNorm2d(320, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(320, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer4): _DenseLayer(
              (norm1): BatchNorm2d(352, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(352, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer5): _DenseLayer(
              (norm1): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(384, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer6): _DenseLayer(
              (norm1): BatchNorm2d(416, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(416, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer7): _DenseLayer(
              (norm1): BatchNorm2d(448, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(448, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer8): _DenseLayer(
              (norm1): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(480, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer9): _DenseLayer(
              (norm1): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(512, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer10): _DenseLayer(
              (norm1): BatchNorm2d(544, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(544, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer11): _DenseLayer(
              (norm1): BatchNorm2d(576, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(576, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer12): _DenseLayer(
              (norm1): BatchNorm2d(608, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(608, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer13): _DenseLayer(
              (norm1): BatchNorm2d(640, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(640, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer14): _DenseLayer(
              (norm1): BatchNorm2d(672, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(672, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer15): _DenseLayer(
              (norm1): BatchNorm2d(704, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(704, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer16): _DenseLayer(
              (norm1): BatchNorm2d(736, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(736, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer17): _DenseLayer(
              (norm1): BatchNorm2d(768, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(768, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer18): _DenseLayer(
              (norm1): BatchNorm2d(800, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(800, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer19): _DenseLayer(
              (norm1): BatchNorm2d(832, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(832, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer20): _DenseLayer(
              (norm1): BatchNorm2d(864, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(864, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer21): _DenseLayer(
              (norm1): BatchNorm2d(896, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(896, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer22): _DenseLayer(
              (norm1): BatchNorm2d(928, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(928, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer23): _DenseLayer(
              (norm1): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(960, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer24): _DenseLayer(
              (norm1): BatchNorm2d(992, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(992, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer25): _DenseLayer(
              (norm1): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1024, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer26): _DenseLayer(
              (norm1): BatchNorm2d(1056, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1056, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer27): _DenseLayer(
              (norm1): BatchNorm2d(1088, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1088, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer28): _DenseLayer(
              (norm1): BatchNorm2d(1120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1120, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer29): _DenseLayer(
              (norm1): BatchNorm2d(1152, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1152, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer30): _DenseLayer(
              (norm1): BatchNorm2d(1184, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1184, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer31): _DenseLayer(
              (norm1): BatchNorm2d(1216, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1216, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer32): _DenseLayer(
              (norm1): BatchNorm2d(1248, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1248, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
          )
          (transition3): _Transition(
            (norm): BatchNorm2d(1280, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (relu): ReLU(inplace)
            (conv): Conv2d(1280, 640, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (pool): AvgPool2d(kernel_size=2, stride=2, padding=0)
          )
          (denseblock4): _DenseBlock(
            (denselayer1): _DenseLayer(
              (norm1): BatchNorm2d(640, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(640, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer2): _DenseLayer(
              (norm1): BatchNorm2d(672, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(672, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer3): _DenseLayer(
              (norm1): BatchNorm2d(704, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(704, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer4): _DenseLayer(
              (norm1): BatchNorm2d(736, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(736, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer5): _DenseLayer(
              (norm1): BatchNorm2d(768, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(768, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer6): _DenseLayer(
              (norm1): BatchNorm2d(800, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(800, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer7): _DenseLayer(
              (norm1): BatchNorm2d(832, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(832, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer8): _DenseLayer(
              (norm1): BatchNorm2d(864, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(864, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer9): _DenseLayer(
              (norm1): BatchNorm2d(896, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(896, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer10): _DenseLayer(
              (norm1): BatchNorm2d(928, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(928, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer11): _DenseLayer(
              (norm1): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(960, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer12): _DenseLayer(
              (norm1): BatchNorm2d(992, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(992, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer13): _DenseLayer(
              (norm1): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1024, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer14): _DenseLayer(
              (norm1): BatchNorm2d(1056, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1056, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer15): _DenseLayer(
              (norm1): BatchNorm2d(1088, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1088, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer16): _DenseLayer(
              (norm1): BatchNorm2d(1120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1120, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer17): _DenseLayer(
              (norm1): BatchNorm2d(1152, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1152, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer18): _DenseLayer(
              (norm1): BatchNorm2d(1184, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1184, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer19): _DenseLayer(
              (norm1): BatchNorm2d(1216, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1216, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer20): _DenseLayer(
              (norm1): BatchNorm2d(1248, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1248, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer21): _DenseLayer(
              (norm1): BatchNorm2d(1280, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1280, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer22): _DenseLayer(
              (norm1): BatchNorm2d(1312, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1312, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer23): _DenseLayer(
              (norm1): BatchNorm2d(1344, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1344, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer24): _DenseLayer(
              (norm1): BatchNorm2d(1376, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1376, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer25): _DenseLayer(
              (norm1): BatchNorm2d(1408, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1408, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer26): _DenseLayer(
              (norm1): BatchNorm2d(1440, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1440, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer27): _DenseLayer(
              (norm1): BatchNorm2d(1472, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1472, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer28): _DenseLayer(
              (norm1): BatchNorm2d(1504, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1504, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer29): _DenseLayer(
              (norm1): BatchNorm2d(1536, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1536, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer30): _DenseLayer(
              (norm1): BatchNorm2d(1568, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1568, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer31): _DenseLayer(
              (norm1): BatchNorm2d(1600, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1600, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer32): _DenseLayer(
              (norm1): BatchNorm2d(1632, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1632, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
          )
          (norm5): BatchNorm2d(1664, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
      )
      (1): Sequential(
        (0): AdaptiveConcatPool2d(
          (ap): AdaptiveAvgPool2d(output_size=1)
          (mp): AdaptiveMaxPool2d(output_size=1)
        )
        (1): Flatten()
        (2): BatchNorm1d(3328, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (3): Dropout(p=0.25)
        (4): Linear(in_features=3328, out_features=512, bias=True)
        (5): ReLU(inplace)
        (6): BatchNorm1d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (7): Dropout(p=0.5)
        (8): Linear(in_features=512, out_features=54, bias=True)
      )
    )



fastai的用fit_one_cycle训练错误率很低，比我之前keras验证集准确率高了很多，默认学习率3e-3


```python
learn.fit_one_cycle(4)
```


<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: left;">
      <th>epoch</th>
      <th>train_loss</th>
      <th>valid_loss</th>
      <th>error_rate</th>
      <th>time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2.240991</td>
      <td>0.806248</td>
      <td>0.166220</td>
      <td>00:39</td>
    </tr>
    <tr>
      <td>1</td>
      <td>0.998228</td>
      <td>0.422492</td>
      <td>0.115281</td>
      <td>00:29</td>
    </tr>
    <tr>
      <td>2</td>
      <td>0.505955</td>
      <td>0.279443</td>
      <td>0.072386</td>
      <td>00:28</td>
    </tr>
    <tr>
      <td>3</td>
      <td>0.279887</td>
      <td>0.266836</td>
      <td>0.076408</td>
      <td>00:29</td>
    </tr>
  </tbody>
</table>



```python
learn.save('stage-densenet169-1')
```


```python
interp = ClassificationInterpretation.from_learner(learn)

losses,idxs = interp.top_losses()

len(data.valid_ds)==len(losses)==len(idxs)
```








    True




```python
interp.plot_top_losses(9, figsize=(15,11))
```


![png](output_20_0.png)



```python
interp.plot_confusion_matrix(figsize=(12,12), dpi=60)
```


![png](output_21_0.png)



```python
interp.most_confused(min_val=2)
```




    [('class_52', 'class_36', 4),
     ('class_00', 'class_03', 2),
     ('class_19', 'class_20', 2),
     ('class_21', 'class_11', 2)]




```python
解冻会直接训练默认学习率较大不适合直接fine tune
```


```python
learn.unfreeze()
```


```python
learn.fit_one_cycle(1)
```


<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: left;">
      <th>epoch</th>
      <th>train_loss</th>
      <th>valid_loss</th>
      <th>error_rate</th>
      <th>time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>0.368941</td>
      <td>0.325886</td>
      <td>0.092493</td>
      <td>00:35</td>
    </tr>
  </tbody>
</table>



```python
learn.load('stage-densenet169-1')
```




    Learner(data=ImageDataBunch;
    
    Train: LabelList (2985 items)
    x: ImageList
    Image (3, 299, 299),Image (3, 299, 299),Image (3, 299, 299),Image (3, 299, 299),Image (3, 299, 299)
    y: CategoryList
    class_00,class_01,class_14,class_14,class_14
    Path: .;
    
    Valid: LabelList (746 items)
    x: ImageList
    Image (3, 299, 299),Image (3, 299, 299),Image (3, 299, 299),Image (3, 299, 299),Image (3, 299, 299)
    y: CategoryList
    class_48,class_13,class_03,class_06,class_47
    Path: .;
    
    Test: None, model=Sequential(
      (0): Sequential(
        (0): Sequential(
          (conv0): Conv2d(3, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)
          (norm0): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          (relu0): ReLU(inplace)
          (pool0): MaxPool2d(kernel_size=3, stride=2, padding=1, dilation=1, ceil_mode=False)
          (denseblock1): _DenseBlock(
            (denselayer1): _DenseLayer(
              (norm1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(64, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer2): _DenseLayer(
              (norm1): BatchNorm2d(96, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(96, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer3): _DenseLayer(
              (norm1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(128, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer4): _DenseLayer(
              (norm1): BatchNorm2d(160, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(160, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer5): _DenseLayer(
              (norm1): BatchNorm2d(192, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(192, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer6): _DenseLayer(
              (norm1): BatchNorm2d(224, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(224, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
          )
          (transition1): _Transition(
            (norm): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (relu): ReLU(inplace)
            (conv): Conv2d(256, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (pool): AvgPool2d(kernel_size=2, stride=2, padding=0)
          )
          (denseblock2): _DenseBlock(
            (denselayer1): _DenseLayer(
              (norm1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(128, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer2): _DenseLayer(
              (norm1): BatchNorm2d(160, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(160, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer3): _DenseLayer(
              (norm1): BatchNorm2d(192, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(192, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer4): _DenseLayer(
              (norm1): BatchNorm2d(224, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(224, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer5): _DenseLayer(
              (norm1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(256, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer6): _DenseLayer(
              (norm1): BatchNorm2d(288, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(288, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer7): _DenseLayer(
              (norm1): BatchNorm2d(320, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(320, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer8): _DenseLayer(
              (norm1): BatchNorm2d(352, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(352, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer9): _DenseLayer(
              (norm1): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(384, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer10): _DenseLayer(
              (norm1): BatchNorm2d(416, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(416, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer11): _DenseLayer(
              (norm1): BatchNorm2d(448, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(448, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer12): _DenseLayer(
              (norm1): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(480, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
          )
          (transition2): _Transition(
            (norm): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (relu): ReLU(inplace)
            (conv): Conv2d(512, 256, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (pool): AvgPool2d(kernel_size=2, stride=2, padding=0)
          )
          (denseblock3): _DenseBlock(
            (denselayer1): _DenseLayer(
              (norm1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(256, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer2): _DenseLayer(
              (norm1): BatchNorm2d(288, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(288, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer3): _DenseLayer(
              (norm1): BatchNorm2d(320, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(320, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer4): _DenseLayer(
              (norm1): BatchNorm2d(352, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(352, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer5): _DenseLayer(
              (norm1): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(384, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer6): _DenseLayer(
              (norm1): BatchNorm2d(416, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(416, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer7): _DenseLayer(
              (norm1): BatchNorm2d(448, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(448, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer8): _DenseLayer(
              (norm1): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(480, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer9): _DenseLayer(
              (norm1): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(512, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer10): _DenseLayer(
              (norm1): BatchNorm2d(544, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(544, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer11): _DenseLayer(
              (norm1): BatchNorm2d(576, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(576, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer12): _DenseLayer(
              (norm1): BatchNorm2d(608, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(608, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer13): _DenseLayer(
              (norm1): BatchNorm2d(640, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(640, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer14): _DenseLayer(
              (norm1): BatchNorm2d(672, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(672, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer15): _DenseLayer(
              (norm1): BatchNorm2d(704, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(704, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer16): _DenseLayer(
              (norm1): BatchNorm2d(736, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(736, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer17): _DenseLayer(
              (norm1): BatchNorm2d(768, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(768, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer18): _DenseLayer(
              (norm1): BatchNorm2d(800, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(800, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer19): _DenseLayer(
              (norm1): BatchNorm2d(832, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(832, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer20): _DenseLayer(
              (norm1): BatchNorm2d(864, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(864, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer21): _DenseLayer(
              (norm1): BatchNorm2d(896, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(896, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer22): _DenseLayer(
              (norm1): BatchNorm2d(928, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(928, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer23): _DenseLayer(
              (norm1): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(960, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer24): _DenseLayer(
              (norm1): BatchNorm2d(992, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(992, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer25): _DenseLayer(
              (norm1): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1024, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer26): _DenseLayer(
              (norm1): BatchNorm2d(1056, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1056, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer27): _DenseLayer(
              (norm1): BatchNorm2d(1088, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1088, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer28): _DenseLayer(
              (norm1): BatchNorm2d(1120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1120, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer29): _DenseLayer(
              (norm1): BatchNorm2d(1152, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1152, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer30): _DenseLayer(
              (norm1): BatchNorm2d(1184, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1184, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer31): _DenseLayer(
              (norm1): BatchNorm2d(1216, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1216, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer32): _DenseLayer(
              (norm1): BatchNorm2d(1248, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1248, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
          )
          (transition3): _Transition(
            (norm): BatchNorm2d(1280, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (relu): ReLU(inplace)
            (conv): Conv2d(1280, 640, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (pool): AvgPool2d(kernel_size=2, stride=2, padding=0)
          )
          (denseblock4): _DenseBlock(
            (denselayer1): _DenseLayer(
              (norm1): BatchNorm2d(640, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(640, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer2): _DenseLayer(
              (norm1): BatchNorm2d(672, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(672, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer3): _DenseLayer(
              (norm1): BatchNorm2d(704, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(704, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer4): _DenseLayer(
              (norm1): BatchNorm2d(736, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(736, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer5): _DenseLayer(
              (norm1): BatchNorm2d(768, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(768, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer6): _DenseLayer(
              (norm1): BatchNorm2d(800, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(800, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer7): _DenseLayer(
              (norm1): BatchNorm2d(832, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(832, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer8): _DenseLayer(
              (norm1): BatchNorm2d(864, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(864, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer9): _DenseLayer(
              (norm1): BatchNorm2d(896, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(896, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer10): _DenseLayer(
              (norm1): BatchNorm2d(928, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(928, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer11): _DenseLayer(
              (norm1): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(960, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer12): _DenseLayer(
              (norm1): BatchNorm2d(992, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(992, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer13): _DenseLayer(
              (norm1): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1024, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer14): _DenseLayer(
              (norm1): BatchNorm2d(1056, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1056, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer15): _DenseLayer(
              (norm1): BatchNorm2d(1088, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1088, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer16): _DenseLayer(
              (norm1): BatchNorm2d(1120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1120, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer17): _DenseLayer(
              (norm1): BatchNorm2d(1152, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1152, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer18): _DenseLayer(
              (norm1): BatchNorm2d(1184, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1184, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer19): _DenseLayer(
              (norm1): BatchNorm2d(1216, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1216, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer20): _DenseLayer(
              (norm1): BatchNorm2d(1248, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1248, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer21): _DenseLayer(
              (norm1): BatchNorm2d(1280, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1280, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer22): _DenseLayer(
              (norm1): BatchNorm2d(1312, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1312, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer23): _DenseLayer(
              (norm1): BatchNorm2d(1344, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1344, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer24): _DenseLayer(
              (norm1): BatchNorm2d(1376, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1376, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer25): _DenseLayer(
              (norm1): BatchNorm2d(1408, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1408, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer26): _DenseLayer(
              (norm1): BatchNorm2d(1440, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1440, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer27): _DenseLayer(
              (norm1): BatchNorm2d(1472, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1472, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer28): _DenseLayer(
              (norm1): BatchNorm2d(1504, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1504, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer29): _DenseLayer(
              (norm1): BatchNorm2d(1536, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1536, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer30): _DenseLayer(
              (norm1): BatchNorm2d(1568, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1568, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer31): _DenseLayer(
              (norm1): BatchNorm2d(1600, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1600, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
            (denselayer32): _DenseLayer(
              (norm1): BatchNorm2d(1632, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu1): ReLU(inplace)
              (conv1): Conv2d(1632, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (norm2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (relu2): ReLU(inplace)
              (conv2): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
            )
          )
          (norm5): BatchNorm2d(1664, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
      )
      (1): Sequential(
        (0): AdaptiveConcatPool2d(
          (ap): AdaptiveAvgPool2d(output_size=1)
          (mp): AdaptiveMaxPool2d(output_size=1)
        )
        (1): Flatten()
        (2): BatchNorm1d(3328, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (3): Dropout(p=0.25)
        (4): Linear(in_features=3328, out_features=512, bias=True)
        (5): ReLU(inplace)
        (6): BatchNorm1d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (7): Dropout(p=0.5)
        (8): Linear(in_features=512, out_features=54, bias=True)
      )
    ), opt_func=functools.partial(<class 'torch.optim.adam.Adam'>, betas=(0.9, 0.99)), loss_func=FlattenedLoss of CrossEntropyLoss(), metrics=[<function error_rate at 0x7f6c8ac5dbf8>], true_wd=True, bn_wd=True, wd=0.01, train_bn=True, path=PosixPath('.'), model_dir='models', callback_fns=[functools.partial(<class 'fastai.basic_train.Recorder'>, add_time=True, silent=False)], callbacks=[], layer_groups=[Sequential(
      (0): Conv2d(3, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)
      (1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (2): ReLU(inplace)
      (3): MaxPool2d(kernel_size=3, stride=2, padding=1, dilation=1, ceil_mode=False)
      (4): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (5): ReLU(inplace)
      (6): Conv2d(64, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (7): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (8): ReLU(inplace)
      (9): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (10): BatchNorm2d(96, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (11): ReLU(inplace)
      (12): Conv2d(96, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (13): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (14): ReLU(inplace)
      (15): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (16): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (17): ReLU(inplace)
      (18): Conv2d(128, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (19): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (20): ReLU(inplace)
      (21): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (22): BatchNorm2d(160, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (23): ReLU(inplace)
      (24): Conv2d(160, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (25): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (26): ReLU(inplace)
      (27): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (28): BatchNorm2d(192, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (29): ReLU(inplace)
      (30): Conv2d(192, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (31): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (32): ReLU(inplace)
      (33): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (34): BatchNorm2d(224, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (35): ReLU(inplace)
      (36): Conv2d(224, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (37): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (38): ReLU(inplace)
      (39): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (40): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (41): ReLU(inplace)
      (42): Conv2d(256, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (43): AvgPool2d(kernel_size=2, stride=2, padding=0)
      (44): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (45): ReLU(inplace)
      (46): Conv2d(128, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (47): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (48): ReLU(inplace)
      (49): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (50): BatchNorm2d(160, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (51): ReLU(inplace)
      (52): Conv2d(160, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (53): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (54): ReLU(inplace)
      (55): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (56): BatchNorm2d(192, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (57): ReLU(inplace)
      (58): Conv2d(192, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (59): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (60): ReLU(inplace)
      (61): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (62): BatchNorm2d(224, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (63): ReLU(inplace)
      (64): Conv2d(224, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (65): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (66): ReLU(inplace)
      (67): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (68): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (69): ReLU(inplace)
      (70): Conv2d(256, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (71): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (72): ReLU(inplace)
      (73): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (74): BatchNorm2d(288, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (75): ReLU(inplace)
      (76): Conv2d(288, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (77): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (78): ReLU(inplace)
      (79): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (80): BatchNorm2d(320, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (81): ReLU(inplace)
      (82): Conv2d(320, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (83): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (84): ReLU(inplace)
      (85): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (86): BatchNorm2d(352, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (87): ReLU(inplace)
      (88): Conv2d(352, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (89): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (90): ReLU(inplace)
      (91): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (92): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (93): ReLU(inplace)
      (94): Conv2d(384, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (95): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (96): ReLU(inplace)
      (97): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (98): BatchNorm2d(416, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (99): ReLU(inplace)
      (100): Conv2d(416, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (101): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (102): ReLU(inplace)
      (103): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (104): BatchNorm2d(448, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (105): ReLU(inplace)
      (106): Conv2d(448, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (107): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (108): ReLU(inplace)
      (109): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (110): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (111): ReLU(inplace)
      (112): Conv2d(480, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (113): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (114): ReLU(inplace)
      (115): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
    ), Sequential(
      (0): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (1): ReLU(inplace)
      (2): Conv2d(512, 256, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (3): AvgPool2d(kernel_size=2, stride=2, padding=0)
      (4): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (5): ReLU(inplace)
      (6): Conv2d(256, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (7): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (8): ReLU(inplace)
      (9): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (10): BatchNorm2d(288, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (11): ReLU(inplace)
      (12): Conv2d(288, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (13): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (14): ReLU(inplace)
      (15): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (16): BatchNorm2d(320, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (17): ReLU(inplace)
      (18): Conv2d(320, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (19): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (20): ReLU(inplace)
      (21): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (22): BatchNorm2d(352, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (23): ReLU(inplace)
      (24): Conv2d(352, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (25): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (26): ReLU(inplace)
      (27): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (28): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (29): ReLU(inplace)
      (30): Conv2d(384, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (31): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (32): ReLU(inplace)
      (33): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (34): BatchNorm2d(416, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (35): ReLU(inplace)
      (36): Conv2d(416, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (37): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (38): ReLU(inplace)
      (39): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (40): BatchNorm2d(448, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (41): ReLU(inplace)
      (42): Conv2d(448, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (43): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (44): ReLU(inplace)
      (45): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (46): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (47): ReLU(inplace)
      (48): Conv2d(480, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (49): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (50): ReLU(inplace)
      (51): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (52): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (53): ReLU(inplace)
      (54): Conv2d(512, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (55): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (56): ReLU(inplace)
      (57): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (58): BatchNorm2d(544, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (59): ReLU(inplace)
      (60): Conv2d(544, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (61): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (62): ReLU(inplace)
      (63): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (64): BatchNorm2d(576, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (65): ReLU(inplace)
      (66): Conv2d(576, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (67): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (68): ReLU(inplace)
      (69): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (70): BatchNorm2d(608, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (71): ReLU(inplace)
      (72): Conv2d(608, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (73): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (74): ReLU(inplace)
      (75): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (76): BatchNorm2d(640, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (77): ReLU(inplace)
      (78): Conv2d(640, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (79): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (80): ReLU(inplace)
      (81): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (82): BatchNorm2d(672, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (83): ReLU(inplace)
      (84): Conv2d(672, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (85): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (86): ReLU(inplace)
      (87): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (88): BatchNorm2d(704, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (89): ReLU(inplace)
      (90): Conv2d(704, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (91): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (92): ReLU(inplace)
      (93): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (94): BatchNorm2d(736, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (95): ReLU(inplace)
      (96): Conv2d(736, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (97): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (98): ReLU(inplace)
      (99): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (100): BatchNorm2d(768, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (101): ReLU(inplace)
      (102): Conv2d(768, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (103): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (104): ReLU(inplace)
      (105): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (106): BatchNorm2d(800, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (107): ReLU(inplace)
      (108): Conv2d(800, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (109): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (110): ReLU(inplace)
      (111): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (112): BatchNorm2d(832, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (113): ReLU(inplace)
      (114): Conv2d(832, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (115): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (116): ReLU(inplace)
      (117): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (118): BatchNorm2d(864, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (119): ReLU(inplace)
      (120): Conv2d(864, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (121): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (122): ReLU(inplace)
      (123): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (124): BatchNorm2d(896, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (125): ReLU(inplace)
      (126): Conv2d(896, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (127): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (128): ReLU(inplace)
      (129): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (130): BatchNorm2d(928, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (131): ReLU(inplace)
      (132): Conv2d(928, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (133): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (134): ReLU(inplace)
      (135): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (136): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (137): ReLU(inplace)
      (138): Conv2d(960, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (139): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (140): ReLU(inplace)
      (141): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (142): BatchNorm2d(992, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (143): ReLU(inplace)
      (144): Conv2d(992, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (145): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (146): ReLU(inplace)
      (147): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (148): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (149): ReLU(inplace)
      (150): Conv2d(1024, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (151): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (152): ReLU(inplace)
      (153): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (154): BatchNorm2d(1056, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (155): ReLU(inplace)
      (156): Conv2d(1056, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (157): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (158): ReLU(inplace)
      (159): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (160): BatchNorm2d(1088, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (161): ReLU(inplace)
      (162): Conv2d(1088, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (163): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (164): ReLU(inplace)
      (165): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (166): BatchNorm2d(1120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (167): ReLU(inplace)
      (168): Conv2d(1120, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (169): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (170): ReLU(inplace)
      (171): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (172): BatchNorm2d(1152, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (173): ReLU(inplace)
      (174): Conv2d(1152, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (175): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (176): ReLU(inplace)
      (177): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (178): BatchNorm2d(1184, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (179): ReLU(inplace)
      (180): Conv2d(1184, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (181): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (182): ReLU(inplace)
      (183): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (184): BatchNorm2d(1216, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (185): ReLU(inplace)
      (186): Conv2d(1216, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (187): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (188): ReLU(inplace)
      (189): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (190): BatchNorm2d(1248, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (191): ReLU(inplace)
      (192): Conv2d(1248, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (193): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (194): ReLU(inplace)
      (195): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (196): BatchNorm2d(1280, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (197): ReLU(inplace)
      (198): Conv2d(1280, 640, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (199): AvgPool2d(kernel_size=2, stride=2, padding=0)
      (200): BatchNorm2d(640, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (201): ReLU(inplace)
      (202): Conv2d(640, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (203): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (204): ReLU(inplace)
      (205): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (206): BatchNorm2d(672, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (207): ReLU(inplace)
      (208): Conv2d(672, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (209): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (210): ReLU(inplace)
      (211): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (212): BatchNorm2d(704, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (213): ReLU(inplace)
      (214): Conv2d(704, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (215): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (216): ReLU(inplace)
      (217): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (218): BatchNorm2d(736, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (219): ReLU(inplace)
      (220): Conv2d(736, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (221): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (222): ReLU(inplace)
      (223): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (224): BatchNorm2d(768, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (225): ReLU(inplace)
      (226): Conv2d(768, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (227): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (228): ReLU(inplace)
      (229): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (230): BatchNorm2d(800, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (231): ReLU(inplace)
      (232): Conv2d(800, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (233): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (234): ReLU(inplace)
      (235): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (236): BatchNorm2d(832, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (237): ReLU(inplace)
      (238): Conv2d(832, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (239): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (240): ReLU(inplace)
      (241): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (242): BatchNorm2d(864, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (243): ReLU(inplace)
      (244): Conv2d(864, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (245): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (246): ReLU(inplace)
      (247): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (248): BatchNorm2d(896, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (249): ReLU(inplace)
      (250): Conv2d(896, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (251): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (252): ReLU(inplace)
      (253): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (254): BatchNorm2d(928, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (255): ReLU(inplace)
      (256): Conv2d(928, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (257): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (258): ReLU(inplace)
      (259): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (260): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (261): ReLU(inplace)
      (262): Conv2d(960, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (263): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (264): ReLU(inplace)
      (265): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (266): BatchNorm2d(992, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (267): ReLU(inplace)
      (268): Conv2d(992, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (269): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (270): ReLU(inplace)
      (271): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (272): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (273): ReLU(inplace)
      (274): Conv2d(1024, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (275): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (276): ReLU(inplace)
      (277): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (278): BatchNorm2d(1056, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (279): ReLU(inplace)
      (280): Conv2d(1056, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (281): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (282): ReLU(inplace)
      (283): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (284): BatchNorm2d(1088, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (285): ReLU(inplace)
      (286): Conv2d(1088, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (287): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (288): ReLU(inplace)
      (289): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (290): BatchNorm2d(1120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (291): ReLU(inplace)
      (292): Conv2d(1120, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (293): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (294): ReLU(inplace)
      (295): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (296): BatchNorm2d(1152, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (297): ReLU(inplace)
      (298): Conv2d(1152, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (299): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (300): ReLU(inplace)
      (301): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (302): BatchNorm2d(1184, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (303): ReLU(inplace)
      (304): Conv2d(1184, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (305): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (306): ReLU(inplace)
      (307): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (308): BatchNorm2d(1216, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (309): ReLU(inplace)
      (310): Conv2d(1216, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (311): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (312): ReLU(inplace)
      (313): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (314): BatchNorm2d(1248, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (315): ReLU(inplace)
      (316): Conv2d(1248, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (317): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (318): ReLU(inplace)
      (319): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (320): BatchNorm2d(1280, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (321): ReLU(inplace)
      (322): Conv2d(1280, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (323): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (324): ReLU(inplace)
      (325): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (326): BatchNorm2d(1312, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (327): ReLU(inplace)
      (328): Conv2d(1312, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (329): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (330): ReLU(inplace)
      (331): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (332): BatchNorm2d(1344, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (333): ReLU(inplace)
      (334): Conv2d(1344, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (335): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (336): ReLU(inplace)
      (337): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (338): BatchNorm2d(1376, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (339): ReLU(inplace)
      (340): Conv2d(1376, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (341): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (342): ReLU(inplace)
      (343): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (344): BatchNorm2d(1408, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (345): ReLU(inplace)
      (346): Conv2d(1408, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (347): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (348): ReLU(inplace)
      (349): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (350): BatchNorm2d(1440, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (351): ReLU(inplace)
      (352): Conv2d(1440, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (353): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (354): ReLU(inplace)
      (355): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (356): BatchNorm2d(1472, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (357): ReLU(inplace)
      (358): Conv2d(1472, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (359): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (360): ReLU(inplace)
      (361): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (362): BatchNorm2d(1504, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (363): ReLU(inplace)
      (364): Conv2d(1504, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (365): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (366): ReLU(inplace)
      (367): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (368): BatchNorm2d(1536, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (369): ReLU(inplace)
      (370): Conv2d(1536, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (371): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (372): ReLU(inplace)
      (373): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (374): BatchNorm2d(1568, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (375): ReLU(inplace)
      (376): Conv2d(1568, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (377): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (378): ReLU(inplace)
      (379): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (380): BatchNorm2d(1600, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (381): ReLU(inplace)
      (382): Conv2d(1600, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (383): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (384): ReLU(inplace)
      (385): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (386): BatchNorm2d(1632, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (387): ReLU(inplace)
      (388): Conv2d(1632, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (389): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (390): ReLU(inplace)
      (391): Conv2d(128, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
      (392): BatchNorm2d(1664, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
    ), Sequential(
      (0): AdaptiveAvgPool2d(output_size=1)
      (1): AdaptiveMaxPool2d(output_size=1)
      (2): Flatten()
      (3): BatchNorm1d(3328, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (4): Dropout(p=0.25)
      (5): Linear(in_features=3328, out_features=512, bias=True)
      (6): ReLU(inplace)
      (7): BatchNorm1d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (8): Dropout(p=0.5)
      (9): Linear(in_features=512, out_features=54, bias=True)
    )], add_time=True, silent=False)



One Cycle Policy:The idea is to start with small learning rate (like 1e-4, 1e-3) and increase the learning rate after each mini-batch till loss starts exploding. Once loss starts exploding stop the range test run. Plot the learning rate vs loss plot. Choose the learning rate one order lower than the learning rate where loss is minimum( if loss is low at 0.1, good value to start is 0.01). This is the value where loss is still decreasing. Paper suggests this to be good learning rate value for model.


```python
learn.lr_find()
```





    LR Finder is complete, type {learner_name}.recorder.plot() to see the graph.
    


```python
learn.recorder.plot()
```


![png](output_29_0.png)


用较小的学习率slice有两个参数会分为3个阶段，这种效果很好，错误率降低到6%


```python
learn.unfreeze()
learn.fit_one_cycle(2, max_lr=slice(1e-6,1e-4))
```


<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: left;">
      <th>epoch</th>
      <th>train_loss</th>
      <th>valid_loss</th>
      <th>error_rate</th>
      <th>time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>0.140254</td>
      <td>0.250142</td>
      <td>0.068365</td>
      <td>00:34</td>
    </tr>
    <tr>
      <td>1</td>
      <td>0.125309</td>
      <td>0.246832</td>
      <td>0.064343</td>
      <td>00:33</td>
    </tr>
  </tbody>
</table>



```python
learn.save('stage-densenet169-2')
```


```python

```
